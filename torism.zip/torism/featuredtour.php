<html>
<head>
    <title>
        Tour
    </title>
</head>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="style.css">
<style>
    #footer {
        background-color: gray;
        padding: 10px;
        font-family: "Baskerville Old Face";
    }
.D{
background-color: blue;
color:white;
height:30px;
border:none;
border-radius:10px;
}
.D :hover
{
    background-color: white;
    color:blue;
}

    #above-footer{
        background-color: whitesmoke;
        padding: 40px;
        margin: 0px;
        padding-left: 150px;
        width: 100%;
    }
    #above-footer th{
        font-size: 15px;
        padding-left: 35px;
    }
    #above-footer td{
        color: black;
        text-align: center;
        font-size: 20px;
        padding: 0%;
    }
    #above-footer img{
        padding: 10px;
    }
    #footer-data th{
        margin: 0px;
        padding: 30px;
        padding-left: 90px;
        padding-bottom: 5px;
        text-align: center;
        font-size:22px;
        color: whitesmoke;
    }
    td{
        margin: 0px;
        padding-left: 90px;
        text-align:left;
        color: whitesmoke;
    }
    #spclpck{
        height: 200px;
        background-color: #5bc0de;
        margin-bottom: 50px;
    }
    #spclpck-img img{
        width: 92%;
        padding-left: 250px;
    }
    #spclpck-para{
        font-size: 15px;
    }
    #spclpck-para input{
        padding-top: 4px;
        width: 390px;
        height: 60px;
        background-color: #c9302c;
        font-size: 25px;
        font: bold;
        border-style: groove;
        border-width: 3px;

    }
    #car-options{
        display: flex;
        flex-flow: row wrap;
        /*align-content: space-between;*/
        /*justify-content: space-between;*/
    }
    #car-options table{

        margin: 20px;
        font-size: 20px;
    }
    .row{
        margin: 20px;
    }
    .car-opt{

        background-color: rgba(236, 250, 250, 0.02);
        box-shadow: 10px 10px 5px gray;
        width: 320px;
    }
    #car-opt ul li{

        font-size: 25px;
    }
    .car-img img{
        width: 210px;


    }

    #car-options #cars {

        padding-bottom: 280px;

        font-size: 30px;
    }
    .dp{
        margin-top: -3px;
        width:270px;
        height: 50px;
        background-color: #3C4249;
        color: white;

    }
</style>
<body>
<?php
if(isset($_COOKIE['userid']))
{
$user=$_COOKIE['userid'];
}
else{
$user=0;
}
?>
<button id="userinfo"  style="display: none" value="<?php echo $user?>"></button>
<div class="booking"  style="display: flex; flex-flow: row wrap;">
    <?php
    include 'conn.php';
    $str="select * from tour";
    $result=$sql->query($str);
    if($result->num_rows>0)
    {
        while ($row=$result->fetch_assoc())
        {
            $cid=$row['Id'];
            ?>
            <!--            <tr>-->
            <!--                <td width="100px"><h5 >--><?php //echo $row['id']?><!--</h5> </td>-->
            <!--                <td><h6 >--><?php //echo $row['CarName']?><!-- </h6></td>-->
            <!--                <td><h6 >--><?php //echo $row['Description']?><!-- </h6></td>-->
            <!--                <td><image type="text" style="width:95px;height:45px" id="" src="--><?php //echo $row['Image']?><!--" ></td>-->
            <!--                <td><h6 >--><?php //echo $row['OwnedBy']?><!-- </h6></td>-->
            <!--                <td><h6 >--><?php //echo $row['Rates']?><!-- </h6></td>-->
            <!--                <td><h6 >--><?php //echo $row['Status']?><!-- </h6></td>-->
            <!--            </tr>-->
            <!--            id 	TourName 	Description 	HotelName 	Images 	Location 	RoomsAvailable 	Cost 	Rates-->
            <div class="books" style="height:550px;width:250px;margin-left: 220px;background-color: #ECF6FF;" >
                <img class="D"  src="<?php echo $row['Images']?>" style="width:250px ;height:250px;">
                <br>
                <br>
                <p style="color:#2D3E52;font-size: medium"><?php echo $row['TourName']?></p>
                <p style="color:#A7B0BA;font-size: smaller;"><?php echo $row['Description']?></p>
                <label style="color: red;margin-left: 200px;font-size: 12pt;margin-top: 110px;"><?php echo $row['Cost']?></label>
                <label style="color: red;font-size: 8pt;margin-top: 20px;margin-left: 200px">USD</label>
                <button onclick="catt(<?php  echo $cid?>)" class="D" style="margin-top:8px;">Book Now</button>
            </div>
            <?php
        }
    }

    ?>


</div>
<script>
    function catt(id) {
         var c=document.getElementById('userinfo').value;
        if(c==0)
        {
            alert("please login before booking");
        }
        else
        {
            window.location.href = "http://localhost/torism/inserttour.php?id="+id;
        }
    }
</script>

</body>
</html>