<?php
$sql=mysqli_connect('localhost','root','','torism');
?>