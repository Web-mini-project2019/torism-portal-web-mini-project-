<!DOCTYPE html>
<html>
<head>

    <title>Registration</title>

    <link rel="stylesheet" href="css/style1.css">
    <script src="js/jquery-3.1.1.js"></script>
    <script src="js/script.js"></script>

</head>
<body>
<div>
    <button style="width:1000px;height:100px;margin-left:280px;font-size:30px;text-align:left;background-color: transparent;border:none;">REGISTRATION                        </button>
</div>
<div class="maindiv" style="margin-left: 250px;" >


    <div class="right" style="background-color:#FFFFFF;width: 500px;height:570px;margin-left:30px;font-size:16px;border: 1px solid #428BCA;">
        <button style="text-align: left;background-color: #428BCA;color:white;height: 30px;width: 500px;border:none;border-top-left-radius: 4px;border-top-right-radius: 4px">PERSONAL INFORMATION</button><br><br>


        </select><br><br>
        <label class="texts ">User Name</label>  <br><input type="text" name="first"  id="uname"><br><br>
        <label class="texts "> Email</label> <br><input type="email" name="email" id="email"><br><br>
        <label class="texts "> Password</label><br> <input  type="password" id="pass"><br><br>
        <label class="texts "> ContactNumber</label><br><input type="text" id="phone"><br><br>
        <label class="texts "> Address</label><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<textarea type="number" id="addr"></textarea><br><br>



        <button style="background-color: #1b6d85;border:none;margin-left:50px;" id="reg" >SUBMIT </button>

    </div>


</body>
</html>