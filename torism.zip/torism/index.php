<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>MakeTrip</title>

    <link rel="stylesheet" href="style.css">
    <script src="js/jquery-3.1.1.js"></script>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
<!--    <script src="js/script.js"></script>-->
<!--    <script src="js/v.js"></script>-->
    <script src="js/admin.js"></script>
    <link rel="stylesheet" href="css/font.css">
    <link rel="stylesheet" href="css/w3.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <style>
        .top1 input[type="button"] {background-color: #FFFFFF;border: 0px;height:60px;}
        .top1 input[type="button"]:hover{background-color: #ECECEC}
        #footer {
            background-color: gray;
            padding: 10px;
            font-family: "Baskerville Old Face";
        }
        #above-footer{
            background-color: whitesmoke;
            padding: 40px;
            margin: 0px;
            padding-left: 150px;
            width: 100%;
        }
        #above-footer th{
            font-size: 15px;
            padding-left: 35px;
        }
        #above-footer td{
            color: black;
            text-align: center;
            font-size: 20px;
            padding: 0%;
        }
        #above-footer img{
            padding: 10px;
        }
        #footer-data th{
            margin: 0px;
            padding: 30px;
            padding-left: 90px;
            padding-bottom: 5px;
            text-align: center;
            font-size:22px;
            color: whitesmoke;
        }
        td{
            margin: 0px;
            padding-left: 90px;
            text-align:left;
            color: whitesmoke;
        }
        #spclpck{
            height: 200px;
            background-color: #5bc0de;
            margin-bottom: 50px;
        }
        #spclpck-img img{
            width: 92%;
            padding-left: 250px;
        }
        #spclpck-para{
            font-size: 15px;
        }
        #spclpck-para input{
            padding-top: 4px;
            width: 390px;
            height: 60px;
            background-color: #c9302c;
            font-size: 25px;
            font: bold;
            border-style: groove;
            border-width: 3px;

        }
        #car-options{
            display: flex;
            flex-flow: row wrap;
            /*align-content: space-between;*/
            /*justify-content: space-between;*/
        }
        #car-options table{

            margin: 20px;
            font-size: 20px;
        }
        .row{
            margin: 20px;
        }
        .car-opt{

            background-color: rgba(236, 250, 250, 0.02);
            box-shadow: 10px 10px 5px gray;
            width: 320px;
        }
        #car-opt ul li{

            font-size: 25px;
        }
        .car-img img{
            width: 210px;

           
        }

        #car-options #cars {

            padding-bottom: 280px;

            font-size: 30px;
        }
        .dp{
            margin-top: -3px;
            width:270px;
            height: 50px;
            background-color: #3C4249;
            color: white;

        }
        .adminprofile{
            width:40vh;
            height:70px;
        }
        .dashboard{
            margin: 20px;
            width:1060px;
            height: 200px;
            background-color: #3C4249;

        }
        .sus{
            height: 20px;
            width: 50px;
        }
        .mySlides {display:none;}
    </style>

    <link rel="stylesheet" href="style.css">

</head>
<script>
    var myIndex = 0;
    carousel();

    function carousel() {
        var i;
        var x = document.getElementsByClassName("mySlides");
        for (i = 0; i < x.length; i++) {
            x[i].style.display = "none";
        }
        myIndex++;
        if (myIndex > x.length) {myIndex = 1}
        x[myIndex-1].style.display = "flex";
        setTimeout(carousel, 2000); // Change image every 2 seconds
    }
</script>
<body>

<div class="top" style="background-color:#172448;height: 30px;width:auto;margin:0px"></div>
<div class="top1" style="background-color:#FFFFFF;height: 60px;width:auto;">

    <img src="img/logo.png" style="width: 150px;height: 50px;margin-left:250px">


    <div class="w3-dropdown-hover droprwidth" style="margin-left:550px;background-color:#ECECEC;">
        <button class="w3-button  dp ">MY ACCOUNT</button>
        <div class="w3-dropdown-content w3-bar-block  ">
            <a href="loginn.php" class="w3-bar-item w3-button">Login</a>
            <a href="registrationn.php" class="w3-bar-item w3-button">SignUp</a>
            <a href="logout.php" class="w3-bar-item w3-button">Logout</a>
        </div>
    </div>




</div>
<div class="container" style="max-width:1800px;">
</div>
<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
        <div class="item active">
            <img src="img/slider1.jpg" alt="Los Angeles" style="width:1600px;">
        </div>
        <div class="item">
            <img src="img/1.jpg" alt="Chicago" style="width:1500px;height: 420px;" />
        </div>

        <div class="item">
            <img src="img/slider1.jpg"  alt="Newyork" style="width:1600px;"/>
        </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right"></span>
        <span class="sr-only">Next</span>
    </a>
</div>
<!--<div  class="home1" style="height:251px;width:1110px;margin-left: 225px;margin-top: -295px;position: absolute;border-radius:10px; ">-->

</div>
<!--<div  class="home" style="height:250px;width:1100px;margin-left: 225px;margin-top:-250px;position: absolute;">-->
<!--    <ul  id="a">-->
<!--        <li style="background-color: blue;"><a >HOME</a></li>-->
<!--        <li><a>FlIGHTS</a></li>-->
<!--        <li><a>TOURS</a></li>-->
<!--        <li><a>CARS</a></li>-->
<!--    </ul>-->
<!--    <ul id="b"  >-->
<!--        <li><input type="text" placeholder="Search By Hotel or City Name"/></li>-->
<!--        <li> <input type="text" placeholder="Check-In"/></li>-->
<!--        <li> <input type="text" placeholder="Check-Out"/></li>-->
<!--        <li> <input style="background-color: #00207C;height:35px;width:150px;color: white" type="button" value="Search"/></li>-->
<!---->
<!--    </ul>-->
<!--</div>-->
<?php
include 'featuredflight.php';
?>

<br>

<h3 style="text-align: center">Featured Tour</h3>
<br>
<?php
include 'featuredtour.php';

?>
<table>
    <tr ><th><img src="carlogo.jpg" style="width: 80px"></th><th style="font-size: 30px" >Featured Cars</th></tr>
</table>
<?php
include 'featuredcar.php';
include 'footer.php'
?>
</body>
</html>