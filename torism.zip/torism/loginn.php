<!DOCTYPE html>
<html>
<head>

    <title>Registration</title>

<!--    <link rel="stylesheet" href="css/style1.css">-->
    <link rel="stylesheet"href="css/bootstrap.min.css">
    <script src="js/jquery-3.1.1.js"></script>
    <script src="js/script.js"></script>

</head>
<style>
    .form-container{
        width: 30%;
        margin: 5% 35%;
        box-shadow: 0 0 5px #000000;
        padding: 20px;
        border-radius: 20px;
    }
    h1{ text-align: center}
</style>
<body>

<div class="form-container">
    <h1>Login</h1>
    <form method="post" action="">
        <div class="form-group">
            <label >User Name</label>
            <input class="form-control" type="text" id="uname" name="uname">
        </div>
<div class="form-group">
    <label >Type</label>
    <select name="field" class="form-control">
        <option>admin</option>
        <option>user</option>
    </select>
</div>

        <div class="form-group">
            <label class="texts "> Password</label>
            <input class="form-control" type="password" id="pass" name="pass" val="">
        </div>




        <input   class="btn btn-block btn-success" type="submit"  id="reg" name="reg" />


    </form>
</div>


    <?php
    if(isset($_POST['reg']))
    {
        $field=$_POST['field'];
        if($field=='user')
        {
            $uname=$_POST['uname'];
            $pass=$_POST['pass'];
            include 'conn.php';
            $str="select * from user where Username='$uname' and Password='$pass'and Status=1";
            $result=$sql->query($str);
            if(mysqli_num_rows($result)>0)
            {
                while ($row = $result->fetch_assoc())
                {
                    $userid=$row['Id'];
                    echo "$userid";
                }
                $result=$sql->query($str);
                setcookie("userid",$userid,30*24*60*60+time());
                echo'<script type="text/javascript">alert("login succesfull");</script>';
                header("Location:index.php");

            }
            else{
                echo'<script type="text/javascript">alert(" login  not succesfull");</script>';
            }
            }
            else if($field=='admin')
            {
                $uname=$_POST['uname'];
                $pass=$_POST['pass'];
                include 'conn.php';
                $str2="select * from admin where Name='$uname' and Password='$pass' ";
                $res2=mysqli_query($sql,$str2);

                if(mysqli_num_rows($res2)>0)
                {
                   header("Location:adminn.php");

                }
                else{
                    echo'<script type="text/javascript">alert("please enter valid pass or username");</script>';
                }
            }
    }
    ?>


</body>
</html>