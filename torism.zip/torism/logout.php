<?php
$userid=$_COOKIE['userid'];
setcookie("userid",$userid,1+time());
header("Location:index.php");
?>