
<?php
$id=$_GET['id'];
echo "$id";
?>
<html>
<head>
    <meta charset="UTF-8">
    <title>Audi R8</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="car1.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <style>
        .top1 input[type="button"] {background-color: #FFFFFF;border: 0px;height:60px;}
        .top1 input[type="button"]:hover{background-color: #ECECEC}
        #footer {
            background-color: gray;

            padding: 10px;
            font-family: "Baskerville Old Face";
        }
        #above-footer{
            background-color: whitesmoke;
            padding: 40px;
            margin: 0px;
            padding-left: 150px;
            width: 100%;
        }
        #above-footer th{
            font-size: 15px;
            padding-left: 35px;
        }
        #above-footer td{
            color: black;
            text-align: center;
            font-size: 20px;
            padding: 0%;
        }
        #above-footer img{
            padding: 10px;
        }
        #footer-data th{
            margin: 0px;
            padding: 30px;
            padding-left: 90px;
            padding-bottom: 5px;
            text-align: center;
            font-size:22px;
            color: whitesmoke;
        }
        td{
            margin: 0px;
            padding-left: 90px;
            text-align:left;
            color: whitesmoke;
        }
        #spclpck{
            height: 200px;
            background-color: #5bc0de;
            margin-bottom: 50px;
        }
        #spclpck-img img{
            width: 92%;
            padding-left: 250px;
        }
        #spclpck-para{
            font-size: 15px;
        }
        #spclpck-para input{
            padding-top: 4px;
            width: 390px;
            height: 60px;
            background-color: #c9302c;
            font-size: 25px;
            font: bold;
            border-style: groove;
            border-width: 3px;

        }
        #car-options table{

            margin: 20px;
            font-size: 20px;
        }
        #car-opt{

            background-color: rgba(236, 250, 250, 0.02);
            box-shadow: 10px 10px 5px gray;

            margin-left: 30px;
            width: 300px;
            height: 350px;
            padding-bottom: 50px;
        }
        #car-opt ul li{
            padding-left: 0px;
            margin-left: 0px;
            font-size: 25px;
        }
        #car-img img{
            width: 210px;
            position: absolute;
            left: 40px;
        }

        #car-options #cars {

            padding-bottom: 120px;

            font-size: 30px;
        }

    </style>
    <link rel="stylesheet" href="style.css">
</head>

<body>
<div class="top1" style="background-color:#FFFFFF;height: 80px;width:100%;">
    <img src="img/logo.png" style="width: 160px;height: 70px;margin-left:170px">
    <input type="button" value="FLIGHTS" style=" font-family:'Times New Roman'; margin-left: 15px;font-size: 20px">
    <input type="button" value="TOURS" style=" font-family:'Times New Roman'; margin-left: 15px;font-size: 20px">
    <input type="button" value="CARS" style=" font-family:'Times New Roman'; margin-left: 15px;font-size: 20px">


    <button style="margin-left:200px;background-color:#ECECEC;border:0px;height:30px;width: 130px;" id="Account">MY ACCOUNT</button>

</div>

<?php
include 'conn.php';
$str="select * from car where id=$id";
$result=$sql->query($str);
if($result->num_rows>0)
{
    while ($row = $result->fetch_assoc())
    {
        $cid=$row['id'];
        ?>

    <div>
        <div class="row" id="car-info">
            <div class="col-md-6" id="car-content">
                <p id="car-name"><?php // echo $row['CarName'] ?></p>
                <p id="car-loc"><img src="locationlogo.jpg" id="loclogo-img" /> Muskat</p>
                <br>
                <img src="<?php echo $row['Image'] ?>" id="carimage"/>
            </div>

            <div class="col-md-6" id="car-book">
<!--                <table border="2 solid" style="border-color: #87CEEB;border-width: 3px" >-->
<!--                    <tr id="book-table">-->
<!--                        <th style="font-size: 30px; text-align: center">Booking</th>-->
<!--                    </tr>-->
<!--                    <tr>-->
<!--                        <td>-->
<!--                            <p>Pick Up Date</p>-->
<!--                            <input type="date" id="pickup">-->
<!--                        </td>-->
<!--                    </tr>-->
<!--                    <tr>-->
<!--                        <td>-->
<!--                            <p>Pick Up Location</p>-->
<!--                            <input type="text" id="pick-loc">-->
<!--                        </td>-->
<!--                    </tr><tr>-->
<!--                        <td>-->
<!--                            <p>Drop Off Location</p>-->
<!--                            <input type="text" id="drop-loc">-->
<!--                        </td>-->
<!--                    </tr>-->
<!--                    <tr>-->
<!--                        <td>-->
<!--                            <p style="font-size:15px;color: black">Drop Off Date</p>-->
<!--                            <input type="date" id="dropoff">-->
<!--                        </td>-->
<!--                    </tr>-->
<!--                    <tr>-->

                <div style="width: 300px;background-color: #FFFFFF;margin-top:-150px;height: 650px;margin-left: 70px; box-shadow: 10px 10px 5px gray;"><button style="width: 300px;background-color: #3E50B4;color:#FFFFFF;border:none;height:60px;font-size: 20px;">Booking Option</button>
                    <div class="BookNow" style="padding:30px;">

                        <label style="color:#515151">Pick Up Date</label><input id="pickup" type="date" style="border-color: #F4F6F8;height:40px;width:160px;border-radius: 2px;margin-left: 8px;">
                        <hr>
                        <label style="color:#515151">Pick Up Location </label><input id="pick-loc" type="text" style="border-color: #F4F6F8;height:40px;width:160px;border-radius: 2px;margin-left: 8px;">
                        <hr>
                        <label style="color:#515151">Drop Off Location </label><input id="drop-loc" type="date" style="border-color: #F4F6F8;height:40px;width:160px;border-radius: 2px;margin-left: 8px;">
                        <hr>
                        <label style="color:#515151">Drop Off Date</label><input id="dropoff" type="date" style="border-color: #F4F6F8;height:40px;width:160px;border-radius: 2px;margin-left: 8px;">
                        <hr>

                        <button onclick="booking(<?php echo $id?>)" value="BOOK" id="book" style="width: 235px;background-color: #E54B4B;color:#FFFFFF;border:none;height:55px;border-radius: 2px;font-size: 17px">Book Now</button>
                    </div>

                </div>

                //
            </div>
        </div>
        <div class="row" id="sharelogo">
            <img src="facebkshare.jpg" class="shareimg"/>
            <img src="tweetshare.jpg" class="shareimg"/>
            <img src="pintrestshare.jpg" class="shareimg"/>
            <img src="whatsapp-share.png" class="shareimg"/>
            <img src="sharelogo.jpg" class="shareimg">
        </div>
        <br><br>
        <div class="row" id="carreview">
            <div class="col-lg-8">
                <table>
                    <tr>
                        <th style="font-family: 'Times New Roman';font-size: 30px; padding-left: 90px">Description</th>
                    </tr>
                    <tr>
                        <td><p id="review"> The Hyundai Elantra Sport offers all the comforts a top-trim, non-luxury, compact sedan should. Leather comes standard on the heated front seats, rear bench, flat-bottom sport steering wheel, and gear-shift lever, all of which makes the cabin feel more upscale. The seats are soft and supportive, and even with the design’s aggressive cues, it’s as comfortable as the regular Elantra on the highway.

                                The Elantra Sport's added ingredients don’t detract from space. Passengers over six-foot tall will be comfortable in the two front seats. The Elantra Sport’s front headroom (38.3 inches) and legroom (42.2 inches) are near-best in class. The three-across rear bench seat is just as vast and it’s capable of comfortably accommodating larger passengers on longer bouts.The Elantra Sport’s turbocharged 1.6-liter engine is an appealing powertrain. It produces a healthy 201 horsepower and 195 pound-feet of torque. Against the Honda Civic Si (205 hp) and Volkswagen Jetta GLI (228 hp), it’s a bit down on power. But the Elantra Sport doesn't feel sluggish. It has plenty of power throughout its rev range and little turbo lag.</p></td>
                    </tr>
                </table>
            </div>
        </div>



    </div>

        <?php
    }
}

?>
<?php
include 'featuredtour.php';
include 'footer.php';
?>
<script>
    function booking(carid) {
        // pickup pick-loc drop-loc dropoff
        var pickupdate=document.getElementById('pickup').value;
        var pickloc=document.getElementById('pick-loc').value;
        var droploc=document.getElementById('drop-loc').value;
        var dropoffdate=document.getElementById('dropoff').value;
        window.location.href = "http://localhost/torism/Booking.php?id="+carid+"&pickupdate="+pickupdate+"&picklocation="+pickloc+"&droplocation="+droploc+"&dropdate="+dropoffdate;
        // window.location.href = "http://localhost/torism/insertcar.php?id="+id;
        // window.location.href = "http://localhost/torism/booking.php?id="+carid+"pickupdate="+pickupdate+"picklocation="+pickloc+"droplocation="+droploc+"dropdate="+dropoffDate;
    }
</script>
</body>
</html>