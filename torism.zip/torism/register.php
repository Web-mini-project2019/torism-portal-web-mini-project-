<!DOCTYPE html>
<html>
<head>

    <title>Page Title</title>

    <link rel="stylesheet" href="css/style1.css">
    <script src="js/jquery-3.1.1.js"></script>
    <script src="js/reservation-entry.js"></script>
</head>
<body>

<div class="register" style="background: white;width: 500px;height:300px;margin-left:450px;margin-top:100px;font-size:16px;border: 1px solid #428BCA;">
    <button style="background-color: #428BCA;color:white;height: 60px;width: 500px;border:none;border-top-left-radius: 4px;border-top-right-radius: 4px;font-size:20px">LOGIN</button><br><br>

    <label class="texts ">User Name</label>  <br><input type="text"id="firstname" name="first"><br><br>

    <label class="texts "> Password</label> <br><input type="password" id="password" name="password"><br><br>
    <button class="register" style="background-color: #428BCA;color:white;height:45px;width: 140px;margin-left:160px;border:none;border-radius:3px">LOGIN</button>
</div>
</body>
</html>