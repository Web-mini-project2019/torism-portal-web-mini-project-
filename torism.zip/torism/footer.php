<html>
<head>
    <title>
        footer
    </title>
</head>
<style>
    .top1 input[type="button"] {background-color: #FFFFFF;border: 0px;height:60px;}
    .top1 input[type="button"]:hover{background-color: #ECECEC}
    #footer {
        background-color: gray;
        padding: 10px;
        font-family: "Baskerville Old Face";
    }
    #above-footer{
        background-color: whitesmoke;
        padding: 40px;
        margin: 0px;
        padding-left: 150px;
        width: 100%;
    }
    #above-footer th{
        font-size: 15px;
        padding-left: 35px;
    }
    #above-footer td{
        color: black;
        text-align: center;
        font-size: 20px;
        padding: 0%;
    }
    #above-footer img{
        padding: 10px;
    }
    #footer-data th{
        margin: 0px;
        padding: 30px;
        padding-left: 90px;
        padding-bottom: 5px;
        text-align: center;
        font-size:22px;
        color: whitesmoke;
    }

</style>
<body>
<div id="above-footer">
    <div class="row">
        <table>
            <tr >
                <th rowspan="2" ><img src="7298call.png"></th>
                <th >Need Help? Call Now:</th>
                <th  rowspan="2" style=" border-right:1px black solid"></th>
                <th rowspan="2"><img src="7297mail.png"></th>
                <th>24/7 Customer Support:</th>
                <th  rowspan="2" style=" border-right:1px black solid"></th>
                <th>Find us on our social media channels:</th>
            </tr>
            <tr>
                <td>+124-88008238</td>
                <td>Info@maketrip.com</td>
                <td><img src="7294.png"><img src="729370rs.png.png"><img src="726746yt.png"><img src="7295.png"><img src="7296.png"></td>
            </tr>
        </table>
    </div>
</div>

<div id="footer">
    <div class="row">
        <table >
            <tr id="footer-data">
                <th>Company</th>
                <th>Support</th>
                <th> Business</th>
                <th>Supplier</th>
                <th rowspan="6"> <img src="img/logo.png" style="width: 190px;height: 149px;margin-left:120px"></th>

            </tr>
            <tr >
                <td>Contacts</td>
                <td>Our Partners</td>
                <td>FAQ's</td>
                <td>Suppliers Signup</td>

            </tr>
            <tr>
                <td>About Us</td>
                <td>Privacy Policy</td>
                <td>Suppliers Login</td>
                <td>Extranet Login</td>
            </tr>
            <tr>
                <td>How To Use</td>
                <td>Terms of Use</td>
            </tr>
            <tr>
                <td>Booking Tips</td>
            </tr>
        </table>
    </div>
    <div>

    </div>
</div>
</body>
</html>