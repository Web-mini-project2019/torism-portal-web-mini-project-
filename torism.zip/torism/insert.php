<?php
include 'connect.php';
$uname=$_POST['unames'];
$emails=$_POST['emails'];
$password=$_POST['password'];
$number=$_POST['numbers'];
$address=$_POST['address'];
$status=0;
$sql="INSERT into user (Username,Email,Password	,ContactNo,Address,Status) values('$uname','$emails','$password','$number','$address','$status')";

if($conn->query($sql))
{
    echo "sucess";

}
else
{
    echo "error";

}
?>
