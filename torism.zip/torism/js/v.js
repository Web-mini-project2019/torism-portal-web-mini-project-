$(document).ready(function() {
    /*$('#book1').click(function(){
        alert('hi');
    })*/
    // var myIndex = 0;
    // carousel();

    // function carousel() {
    //     var i;
    //     var x = document.getElementsByClassName("mySlides");
    //     for (i = 0; i < x.length; i++) {
    //         x[i].style.display = "none";
    //     }
    //     myIndex++;
    //     if (myIndex > x.length) {myIndex = 1}
    //     x[myIndex-1].style.display = "flex";
    //     setTimeout(carousel, 2000); // Change image every 2 seconds
    // }

//     var latest = document.getElementById("lt");
//     //var oldMessage = latest.className;
// latest.tagName='hh'
// latest.className='hi';
// var res=latest.attributes;
// console.log(res.className);
    //latest.innerHTML = oldMessage + "<p>Updated this div with JS</p>";
    $('#a').hide();
    $('#b').hide();
    $('#c').hide();

    $('#b1').hide();
    $('#abc').click(function () {

    })
$('.D').click(function () {
    location.replace("first.html");
})

$('.caring').click(function () {
  alert('hi');
})
})