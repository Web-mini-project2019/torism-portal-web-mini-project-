<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Tours</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-3.1.1.js"></script>
    <script src="js/v.js"></script>
    <style>
       .books{
           width:600px;
           height:600px;
           margin-left: 100px;
           margin-top: 100px;
       }
       #footer {
           background-color: #1A1A1A;

           padding: 10px;
           font-family: "Baskerville Old Face";
       }


       #footer-data th{
           margin: 0px;
           padding: 30px;
           padding-left: 90px;
           padding-bottom: 5px;
           text-align: center;
           font-size:25px;
           color: whitesmoke;
       }
       td{
           margin: 0px;
           padding-left: 90px;
           text-align:left;
           color: whitesmoke;
       }
        .BookNow{
            margin-left:30px;
        }
       div li {
            width:110px;
        }
        li a{
           text-decoration: none;
            color: #000000;
        }
        .ho:hover{
            background-color: #0a0a0a;
            color:white;

        }
      input[type="text"]
      {
          border-style: none;
          border: 2px solid #EDEDED;
      }


    </style>
</head>
<body>
<div class="top1" style="background-color:#FFFFFF;height: 60px;width:auto;">
    <img src="img/logo.png" style="width: 150px;height: 50px;margin-left:250px">
    <button  class="ho"style="margin-left:550px;background-color:#ECECEC;border:none;border-radius:2px;color:#FFFFFF;height:30px;width: 150px;border:1px solid  #0a0a0a;height:45px;">MY ACCOUNT</button>
    <button  class="ho" style="background-color: #ECECEC;border:none;width: 150px;border-radius:2px;border:1px solid  #0a0a0a;height:45px;color:#FFFFFF;">ENGLISH</button>
</div>
    <div style="height:50px;width:auto;background-color:#F4F6F8;">
        <ul >
            <li style="margin-left: 280px"><a >HOME</a></li>
            <li><a>FlIGHTS</a></li>
            <li><a>TOURS</a></li>
            <li><a>CARS</a></li>
        </ul>
    </div>
<div style="height:52px;width:auto;background-color:#FFFFFF;border: 1px solid #F4F6F8 ">
    <ul>
<li style="margin-left: 280px"><a >GALLERY</a></li>
<li><a >OVERVIEW</a></li>
<li><a >AVAILABLE ROOMS</a></li>
<li><a >LOCATION</a></li>
<li><a >POLICY</a></li>
<li><a >REVIEWS</a></li>
    </ul>
</div>
<br>
<br>
<br>
<div style="display: flex">
    <img  class="books" src="img/book1.jpg" style="width: 1000px;margin-top:-2px;height: 620px">
    <div style="width: 300px;background-color: #FFFFFF;height: 650px;margin-left: 70px; box-shadow: 10px 10px 5px gray;">
        <button style="width: 300px;background-color: #3E50B4;color:#FFFFFF;border:none;height:60px;font-size: 20px;">Booking Option</button>
        <div class="BookNow">
            <br>
            <br>
            <input type="date" style="border-color: #F4F6F8;height:40px;width:235px;border-radius: 2px">
            <br>
            <br>
            <button style="width: 235px;background-color: #10C47F;color:#FFFFFF;border:none;height:35px;border-radius: 2px">CHANGE DATE</button>
            <hr>
            <hr style="margin-top:-17px;">
            <label style="color:#515151">Adults $150</label><input type="text" style="border-color: #F4F6F8;height:40px;width:80px;border-radius: 2px;margin-left: 8px;"><label style="color: red;margin-left: 8px;">$300</label>
            <hr>
            <label style="color:#515151">Child $30</label><input type="text" style="border-color: #F4F6F8;height:40px;width:80px;border-radius: 2px;margin-left: 23px;"><label style="color: red;margin-left: 8px;">$300</label>
            <hr>
            <label style="color:#515151">Infant $10</label><input type="text" style="border-color: #F4F6F8;height:40px;width:80px;border-radius: 2px;margin-left: 20px;"><label style="color: red;margin-left: 8px;">$300</label>

            <hr>
            <h2>Total USD $300 </h2>
            <h6 style="margin-left: 20px;">   Deposit Now USD $30</h6>
            <hr>
           <a href="Booking.html"> <button style="width: 235px;background-color: #E54B4B;color:#FFFFFF;border:none;height:55px;border-radius: 2px;font-size: 17px">Book Now</button></a>
        </div>

    </div>

</div>
<button style="width: 230px;background-color: #6684C0;color:#FFFFFF;border:none;height:45px;border-radius: 2px;margin-left: 100px;">FacebooK</button>
<button style="width: 230px;background-color: #76BBF0;color:#FFFFFF;border:none;height:45px;border-radius: 2px">Twitter</button>
<button style="width: 230px;background-color: #2CD46B;color:#FFFFFF;border:none;height:45px;border-radius: 2px">Whatsapp</button>


<br>
<br>
<br>
<br>
<br>
<br>
<br>
<div id="footer">
    <div class="row">
        <table >
            <tr id="footer-data">
                <th>Company</th>
                <th>Support</th>
                <th> Business</th>
                <th>Supplier</th>
                <th rowspan="6"> <img src="img/logo.png" style="width: 190px;height: 149px;margin-left:120px"></th>

            </tr>
            <tr >
                <td>Contacts</td>
                <td>Our Partners</td>
                <td>FAQ's</td>
                <td>Suppliers Signup</td>

            </tr>
            <tr>
                <td>About Us</td>
                <td>Privacy Policy</td>
                <td>Suppliers Login</td>
                <td>Extranet Login</td>
            </tr>
            <tr>
                <td>How To Use</td>
                <td>Terms of Use</td>
            </tr>
            <tr>
                <td>Booking Tips</td>
            </tr>
        </table>
    </div>


</div>
</body>
</html>