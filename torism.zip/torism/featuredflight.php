<html>
<head>
    <title>
        Tour
    </title>
</head>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="style.css">
<style>
    #footer {
        background-color: gray;
        padding: 10px;
        font-family: "Baskerville Old Face";
    }
    #above-footer{
        background-color: whitesmoke;
        padding: 40px;
        margin: 0px;
        padding-left: 150px;
        width: 100%;
    }
    #above-footer th{
        font-size: 15px;
        padding-left: 35px;
    }
    #above-footer td{
        color: black;
        text-align: center;
        font-size: 20px;
        padding: 0%;
    }
    #above-footer img{
        padding: 10px;
    }
    #footer-data th{
        margin: 0px;
        padding: 30px;
        padding-left: 90px;
        padding-bottom: 5px;
        text-align: center;
        font-size:22px;
        color: whitesmoke;
    }
    td{
        margin: 0px;
        padding-left: 90px;
        text-align:left;
        color: whitesmoke;
    }
    #spclpck{
        height: 200px;
        background-color: #5bc0de;
        margin-bottom: 50px;
    }
    #spclpck-img img{
        width: 92%;
        padding-left: 250px;
    }
    #spclpck-para{
        font-size: 15px;
    }
    #spclpck-para input{
        padding-top: 4px;
        width: 390px;
        height: 60px;
        background-color: #c9302c;
        font-size: 25px;
        font: bold;
        border-style: groove;
        border-width: 3px;

    }
    #car-options{
        display: flex;
        flex-flow: row wrap;
        /*align-content: space-between;*/
        /*justify-content: space-between;*/
    }
    #car-options table{

        margin: 20px;
        font-size: 20px;
    }
    .row{
        margin: 20px;
    }
    .car-opt{

        background-color: rgba(236, 250, 250, 0.02);
        box-shadow: 10px 10px 5px gray;
        width: 320px;
    }
    #car-opt ul li{

        font-size: 25px;
    }
    .car-img img{
        width: 210px;


    }

    #car-options #cars {

        padding-bottom: 280px;

        font-size: 30px;
    }
    .dp{
        margin-top: -3px;
        width:270px;
        height: 50px;
        background-color: #3C4249;
        color: white;

    }
</style>
<body>
<?php
if(isset($_COOKIE['userid']))
{
    $user=$_COOKIE['userid'];
}
else{
    $user=0;
}
?>
<button id="userinfo"  style="display: none" value="<?php echo $user?>"></button>
<!--<div class="read" style="margin-top:50px;display: flex;">-->
<!--<div style="background-color: #ECF6FF;height:280px;width:320px;margin-left: 270px;">-->
<!--    <img src="780975_1.jpg" height="125" width="320"/>-->
<!--    <p  style="color: #0a0a0a;font-size: 12pt;margin-left: 5px"><b>Virgin Gorda beaches and… </b></p>-->
<!--    <p style="color: #707280;margin-left: 5px">Read More</p>-->
<!--    <p style="color: #0a0a0a;font-size: 10pt;margin-left: 5px">This is the second leg of a truly fun week.-->
<!--        There are adventures…</p>-->
<!--</div>-->
<!--<div style="background-color: #ECF6FF;height:280px;width:320px;margin-left: 10px;">-->
<!--    <img src="120331_3.jpg" height="125" width="320"/>-->
<!--    <p  style="color: #0a0a0a;font-size: 12pt;margin-left: 5px"><b>Peace Train A Long Time Coming </b></p>-->
<!--    <p style="color: #707280;margin-left: 5px">Read More</p>-->
<!--    <p style="color: #0a0a0a;font-size: 10pt;margin-left: 5px">mainland Europe and North America,-->
<!--        Iceland has always…</p>-->
<!--</div>-->
<!--<div style="background-color: #ECF6FF;height:280px;width:320px;margin-left: 10px;">-->
<!--    <img src="696228_2.jpg" height="125" width="320"/>-->
<!--    <p  style="color: #0a0a0a;font-size: 12pt;margin-left: 5px"><b> Fiercely Independent Cultures</b></p>-->
<!--    <p style="color: #707280;margin-left: 5px">Read More</p>-->
<!---->
<!--    <p style="color: #0a0a0a;font-size: 10pt;margin-left: 5px">  In a world that is increasingly homogenous,-->
<!--        fiercely independent…</p>-->
<!--</div>-->
<!--</div>-->
<div class="read" style="margin-top:50px; margin-left:100px;display: flex;flex-flow: row wrap;">
<!--    Id FlightName Description Images Rates Status-->
<?php
    include 'conn.php';
    $str="select * from flight f,flightschedular fs where f.id=fs.FightId";
    $result=$sql->query($str);
    if($result->num_rows>0)
    {
        while ($row=$result->fetch_assoc())
        {
            $cid=$row['Id'];
          ?>

    <div style="background-color: #ECF6FF;height:280px;width:320px;margin-left: 10px;">
        <img onclick="cattd(<?php echo $cid?>)" src="<?php echo $row['Images']?>" height="125" width="320"/>
        <p  style="color: #0a0a0a;font-size: 12pt;margin-left: 5px"><b> <?php echo $row['FlightName']?></b></p>

        <p style="color: #707280;margin-left: 5px"><?php echo $row['Source']?>----> <?php echo $row['Destination']?></p>

        <p style="color: #0a0a0a;font-size: 10pt;margin-left: 5px"><?php echo $row['Description']?></p>
    </div>

            <?php
        }
    }

//    ?>
<!---->
<!---->
</div>
<script>
    function cattd(id) {
        var c=document.getElementById('userinfo').value;
        if(c==0)
        {
            alert("please login before booking");
        }
        else
        {
            window.location.href = "http://localhost/torism/insertflight.php?id="+id;
        }
    }
</script>

</body>
</html>