<!DOCTYPE html>
<html>
<head>

    <title>Registration</title>

    <link rel="stylesheet" href="css/style1.css">
<!--    <script src="js/jquery-3.1.1.js"></script>-->
<!--    <script src="js/script.js"></script>-->

</head>
<body>

<div class="maindiv" style="margin-left: 270px;margin-top:200px;" >


    <div class="right" style="background-color:#FFFFFF;width: 500px;height:270px;margin-left:30px;font-size:16px;border: 1px solid #428BCA;">
        <button style="text-align: center;background-color: #428BCA;color:white;height: 30px;width: 500px;border:none;border-top-left-radius: 4px;border-top-right-radius: 4px">LOGIN</button><br><br>

        <form method="post" action="#">
            </select><br><br>
            <label class="texts ">User Name</label>  <br><input style="margin-left:50px; type="text" id="uname" name="uname"><br><br>
            <label class="texts "> Password</label><br> <input style="margin-left:50px; type="password" id="pass" name="pass"><br><br>



            <input  type="submit" style="background-color: #1b6d85;border:none;margin-left:50px;" id="reg" name="regs" />


        </form>

    </div>
    <?php
    if(isset($_POST['regs']))
    {

        $uname=$_POST['uname'];
        $pass=$_POST['pass'];
        include 'conn.php';
        $str="select * from user where Username='$uname' and Password='$pass'";
        $result=$sql->query($str);
//        $res=mysqli_query($sql,$str);
//    if($result->num_rows>0)
//    {
//        while ($row=$result->fetch_assoc())
//        {
//            $cid=$row['Id'];
/*            echo '<script>alert("<?php echo $cid?>")</script>';*/
//        }
//
//    }else
//    {
//        echo 'ki';
//    }
        if(mysqli_num_rows($result)>0)
        {
            while ($row = $result->fetch_assoc())
            {
                $userid=$row['Id'];
                echo "$userid";
            }
            echo "$userid";
//            $result=$sql->query($str);
            setcookie("userid",$userid,30*24*60*60+time());
            echo'<script type="text/javascript">alert("login succesfull");</script>';
            header("Location:index.php");


        }
        else{
            echo'<script type="text/javascript">alert(" login  not succesfull");</script>';
        }
    }

    ?>


</body>
</html>