<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<style>
    input {
        border-radius: 4px ;
        height:30px;
        width: 300px;
        /*margin-left:80px;*/
        background-color: white;
        border-style: none;
        border: 1px solid #EDEDED;
        padding-left: 10px;
    }
</style>
<body style=" background:#F8F9FA;">
<h3 style="text-align: center">Select Payment Method
</h3>
<hr>
<div style="margin-left:25%">

    <br>
    <br>
    <br>
    <label>Pay By:</label>
    <select style="border-radius: 2px;width:500px;height: 50px;">
        <option>Bank Transfer</option>
        <option>Credit Card</option>
        <option>Stripe Credit Card</option>
    </select>
    <br>
    <br>
    <br>
    <form action="#" method="post">
        <div style="background-color: #FFFFFF;padding: 30px;width: 700px; box-shadow: 0 0 3px #000000;border-radius: 4px;">
            <label class="texts ">First Name</label> <label class="b" style="margin-left:305px";>Last Name</label><br>
            <input type="text" name="first"  id="fname" placeholder="First Name">   <input type="text" name="last"  placeholder="Last Name" class="b" style="margin-left:60px"><br><br>
            <label class="texts "> Card Number</label><br><input type="number" id="phone" placeholder="Contact Number" style="width:670px;"><br><br>
            <label class="texts ">Expiry Date</label>                   <label class="b"  style="margin-left:300px";>Card CCV</label><br>
            <input type="date" name="date">          <input  style="margin-left:60px" type="text" name="ccv" class="b" ><br><br>
        </div>
        <br>
        <input type="submit" name="pay" value="Pay Now" style="height: 50px;font-size:17px;width:100px;background-color: #2CD46B;color: #FFFFFF">
    </form>
</div>



<?php

include 'conn.php';
//id
//FlightSid
//CustomerId
//ArrivalTime
//DepartureTime
//Source
//Destination
//Cost
//Status
//d	CustomerId	HotelName	NoOfRooms	BookingDate	Cost	Status
$user=$_COOKIE['userid'];
$cid=$_GET['id'];
$Source=$_GET['Source'];
$Destination=$_GET['Destination'];
$ArrivalTime=$_GET['ArrivalTime'];
$DepartureTime=$_GET['DepartureTime'];
$Cost=$_GET['Cost'];
$status=1;
//http://localhost/torism/pay3.php?id=1&Source=Manglore&Destination=Banglore&ArrivalTime=2019-11-13%2001:01:00&DepartureTime=2019-11-13%2005:18:20&Cost=1000
$str="INSERT INTO flightbooking (FlightSid,CustomerId,ArrivalTime,DepartureTime,Source,Destination,Cost,Status)
 VALUES ('$cid','$user','$ArrivalTime','$DepartureTime','$Source','$Destination','$Cost','$status')";
if(isset($_POST['pay']))
{
    if($sql->query($str)===TRUE)
    {
        echo "<script>alert('BOOKING SUCCESS');</script>";
    }
    else
    {
        echo "<script>alert('ERROR');</script>";
    }
}


?>

</body>
</html>