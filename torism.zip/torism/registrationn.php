<!DOCTYPE html>
<html>
<head>

    <title>Registration</title>

<!--    <link rel="stylesheet" href="css/style1.css">-->
    <link rel="stylesheet"href="css/bootstrap.min.css">

    <script src="js/jquery-3.1.1.js"></script>
    <script src="js/script.js"></script>

</head>

<style>
    .form-container{
        width: 30%;
        margin: 5% 35%;
        box-shadow: 0 0 5px #000000;
        padding: 20px;
        border-radius: 20px;
    }
    h1{ text-align: center}
</style>
<body>
<div>
</div>
<form action="#" method="post">
    <div class="form-container"  >
        <h1>Register Page</h1>
        <div class="form-group">
            <label class="texts ">User Name</label>
            <input class="form-control" type="text" name="first"  id="uname">
        </div>
        <div class="form-group">
            <label class="texts "> Email</label>
            <input  class="form-control" type="email" name="email" id="email">
        </div>
        <div class="form-group">
            <label class="texts "> Password</label>
            <input class="form-control" type="password" id="pass" name="pass">

        </div>
        <div class="form-group">
            <label class="texts "> ContactNumber</label>
            <input  class="form-control" type="number" id="phone" name="phone">

        </div>
        <div class="form-group">
            <label class="texts ">Address</label>
            <textarea  class="form-control" type="text" id="addr" name="addr"></textarea>

        </div>
        <button class="btn btn-block btn-success" id="reg"  name="submit">SUBMIT </button>

    </div>
</form>


<?php
if(isset($_POST['submit']))
{
include 'conn.php';
$first=$_POST['first'];
$email=$_POST['email'];
$pass=$_POST['pass'];
$phone=$_POST['phone'];
$addr=$_POST['addr'];
$status=0;

$str="INSERT INTO user(Username,Email,Password,ContactNo,Address,Status) VALUES ('$first','$email','$pass',$phone,'$addr',$status)";
 if($sql->query($str)===TRUE)
    {
        echo "<script>alert('inserted Succesfully');</script>";
        header("Location:index.php");
    }
    else
    {
        echo "<script>alert('ERROR');</script>";
    }
}
?>
}

</body>
</html>